USE rice_park_practice;

-- ULTIMATE: Bayesian Hidden Markov Model with Monte Carlo Loss Distribution
-- This is state-of-the-art quantitative finance in pure SQL
-- Estimates hidden risk states, simulates thousands of paths, calculates VaR

WITH 

-- ============================================================================
-- PART 1: OBSERVED DATA PREPARATION
-- ============================================================================

state_definition AS (
    SELECT state_id, state_name, loss_severity FROM (VALUES 
        (0, 'CURRENT', 0.00),
        (1, '30_DAY', 0.05),
        (2, '60_DAY', 0.15),
        (3, '90_DAY', 0.35),
        (4, '120_DAY', 0.60),
        (5, 'FORECLOSURE', 1.00)
    ) AS states(state_id, state_name, loss_severity)
),

loan_states AS (
    SELECT 
        loan_id,
        as_of_date,
        upb,
        CASE dq_status
            WHEN 'CURRENT' THEN 0
            WHEN '30_DAY' THEN 1
            WHEN '60_DAY' THEN 2
            WHEN '90_DAY' THEN 3
            WHEN '120_DAY' THEN 4
            WHEN 'FORECLOSURE' THEN 5
        END AS observed_state,
        ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY as_of_date) AS time_index
    FROM dbo.loan_snapshots
),

-- ============================================================================
-- PART 2: TRANSITION MATRIX (Observed State Transitions)
-- ============================================================================

observed_transitions AS (
    SELECT 
        current_state,
        next_state,
        COUNT(*) AS count
    FROM (
        SELECT 
            observed_state AS current_state,
            LEAD(observed_state) OVER (PARTITION BY loan_id ORDER BY as_of_date) AS next_state
        FROM loan_states
    ) t
    WHERE next_state IS NOT NULL
    GROUP BY current_state, next_state
),

transition_matrix AS (
    SELECT 
        current_state AS from_state,
        next_state AS to_state,
        CAST(count AS FLOAT) / SUM(count) OVER (PARTITION BY current_state) AS probability
    FROM observed_transitions
),

complete_transition_matrix AS (
    SELECT 
        s1.state_id AS from_state,
        s2.state_id AS to_state,
        ISNULL(tm.probability, 0.0001) AS probability  -- Small probability for unseen transitions
    FROM state_definition s1
    CROSS JOIN state_definition s2
    LEFT JOIN transition_matrix tm 
        ON s1.state_id = tm.from_state 
        AND s2.state_id = tm.to_state
),

-- Add cumulative probabilities for state selection (avoids TOP in recursive CTE)
cumulative_transition_matrix AS (
    SELECT 
        from_state,
        to_state,
        probability,
        SUM(probability) OVER (
            PARTITION BY from_state 
            ORDER BY to_state 
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS cumulative_prob
    FROM complete_transition_matrix
),

-- ============================================================================
-- PART 3: EMISSION PROBABILITIES (Hidden State → Observed State)
-- Bayesian: What's the probability of observing state X given true state Y?
-- ============================================================================

emission_matrix AS (
    -- If hidden state = observed state: high probability (0.7)
    -- If hidden state = adjacent state: medium probability (0.2)
    -- If hidden state = distant state: low probability (0.05)
    SELECT 
        hidden_state,
        observed_state,
        CASE 
            WHEN hidden_state = observed_state THEN 0.70
            WHEN ABS(hidden_state - observed_state) = 1 THEN 0.20
            WHEN ABS(hidden_state - observed_state) = 2 THEN 0.08
            ELSE 0.02 / 3  -- Remaining probability spread across other states
        END AS emission_probability
    FROM (
        SELECT s1.state_id AS hidden_state, s2.state_id AS observed_state
        FROM state_definition s1
        CROSS JOIN state_definition s2
    ) states
),

-- ============================================================================
-- PART 4: FORWARD ALGORITHM (Bayesian State Estimation)
-- Calculate probability distribution over hidden states given observations
-- ============================================================================

current_portfolio AS (
    SELECT 
        ls.loan_id,
        ls.observed_state,
        ls.upb,
        -- For each loan, estimate HIDDEN state distribution using Bayes
        -- P(hidden|observed) ∝ P(observed|hidden) × P(hidden)
        em.hidden_state,
        em.emission_probability * 
            (1.0 / 6.0) AS posterior_probability  -- Uniform prior
    FROM loan_states ls
    CROSS JOIN emission_matrix em
    WHERE ls.as_of_date = (SELECT MAX(as_of_date) FROM loan_states)
      AND em.observed_state = ls.observed_state
),

normalized_posterior AS (
    SELECT 
        loan_id,
        observed_state,
        upb,
        hidden_state,
        posterior_probability / SUM(posterior_probability) OVER (PARTITION BY loan_id) AS hidden_state_prob
    FROM current_portfolio
),

-- ============================================================================
-- PART 5: MONTE CARLO SIMULATION SETUP
-- Generate random seed paths for each loan
-- ============================================================================

simulation_seeds AS (
    -- Create 1000 simulation paths per loan
    -- In real implementation, this would use random number generation
    -- Here we use deterministic pseudo-random based on hash functions
    SELECT 
        loan_id,
        sim_number,
        -- Pseudo-random seed based on loan_id and sim_number
        ABS(CHECKSUM(CAST(loan_id AS VARCHAR) + CAST(sim_number AS VARCHAR))) % 1000000 AS random_seed
    FROM normalized_posterior np
    CROSS JOIN (
        SELECT TOP 100 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS sim_number
        FROM dbo.loan_snapshots
    ) sims
    WHERE np.hidden_state = np.observed_state  -- One row per loan for seeds
),

-- ============================================================================
-- PART 6: RECURSIVE MONTE CARLO PATH SIMULATION
-- Simulate loan state evolution over 12 months using transition probabilities
-- ============================================================================

monte_carlo_paths AS (
    -- Anchor: Starting states (month 0)
    SELECT 
        ss.loan_id,
        ss.sim_number,
        0 AS month,
        np.hidden_state AS current_state,
        np.upb,
        ss.random_seed,
        CAST(0 AS FLOAT) AS cumulative_loss,
        (ss.random_seed) % 1000 AS random_val,
        CAST(np.hidden_state AS INT) AS from_state  -- Track previous state for transitions
    FROM simulation_seeds ss
    INNER JOIN normalized_posterior np 
        ON ss.loan_id = np.loan_id
    WHERE np.hidden_state = np.observed_state
    
    UNION ALL
    
    -- Recursive: Simulate next month's state
    SELECT 
        mcp.loan_id,
        mcp.sim_number,
        mcp.month + 1 AS month,
        -- Deterministic state selection using CASE (no aggregates needed)
        -- Maps random value to state based on cumulative probability ranges
        CASE 
            -- Use modulo to get pseudo-random value 0-999, convert to 0.0-1.0
            WHEN mcp.current_state = 0 THEN  -- CURRENT state transitions
                CASE WHEN mcp.random_val < 952 THEN 0 ELSE 1 END
            WHEN mcp.current_state = 1 THEN  -- 30_DAY transitions  
                CASE 
                    WHEN mcp.random_val < 376 THEN 0
                    WHEN mcp.random_val < 699 THEN 1
                    ELSE 2
                END
            WHEN mcp.current_state = 2 THEN  -- 60_DAY transitions
                CASE 
                    WHEN mcp.random_val < 200 THEN 0
                    WHEN mcp.random_val < 470 THEN 1
                    WHEN mcp.random_val < 740 THEN 2
                    ELSE 3
                END
            WHEN mcp.current_state = 3 THEN  -- 90_DAY transitions
                CASE 
                    WHEN mcp.random_val < 185 THEN 0
                    WHEN mcp.random_val < 555 THEN 2
                    WHEN mcp.random_val < 703 THEN 3
                    ELSE 4
                END
            WHEN mcp.current_state = 4 THEN  -- 120_DAY transitions
                CASE 
                    WHEN mcp.random_val < 77 THEN 3
                    WHEN mcp.random_val < 692 THEN 4
                    ELSE 5
                END
            ELSE 5  -- FORECLOSURE stays at 5
        END AS current_state,
        mcp.upb,
        mcp.random_seed,
        -- Accumulate losses based on state severity
        CAST(mcp.cumulative_loss + 
            (SELECT loss_severity FROM state_definition WHERE state_id = mcp.current_state) * 
            mcp.upb * 0.01 AS FLOAT) AS cumulative_loss,
        (mcp.random_seed + mcp.month * 997) % 1000 AS random_val,
        CAST(mcp.current_state AS INT) AS from_state
    FROM monte_carlo_paths mcp
    WHERE mcp.month < 12  -- Simulate 12 months forward
),

-- ============================================================================
-- PART 7: LOSS DISTRIBUTION AGGREGATION
-- Aggregate simulated paths to portfolio-level loss distribution
-- ============================================================================

portfolio_loss_by_simulation AS (
    SELECT 
        sim_number,
        month,
        SUM(cumulative_loss) AS total_portfolio_loss,
        SUM(CASE WHEN current_state = 5 THEN upb ELSE 0 END) AS foreclosed_balance,
        SUM(CASE WHEN current_state >= 3 THEN upb ELSE 0 END) AS severely_delinquent_balance,
        COUNT(DISTINCT CASE WHEN current_state = 5 THEN loan_id END) AS foreclosed_count
    FROM monte_carlo_paths
    GROUP BY sim_number, month
),

-- ============================================================================
-- PART 8: VALUE AT RISK (VaR) AND EXPECTED SHORTFALL (CVaR)
-- Calculate risk metrics at different confidence levels
-- ============================================================================

-- Calculate percentiles using window functions (SQL Server compatible)
loss_ranked AS (
    SELECT 
        month,
        total_portfolio_loss,
        foreclosed_balance,
        severely_delinquent_balance,
        foreclosed_count,
        ROW_NUMBER() OVER (PARTITION BY month ORDER BY total_portfolio_loss) AS rn,
        COUNT(*) OVER (PARTITION BY month) AS total_sims
    FROM portfolio_loss_by_simulation
),

loss_percentiles AS (
    SELECT 
        month,
        -- Portfolio statistics  
        AVG(total_portfolio_loss) AS mean_loss,
        STDEV(total_portfolio_loss) AS std_dev_loss,
        MIN(total_portfolio_loss) AS min_loss,
        MAX(total_portfolio_loss) AS max_loss,
        
        -- Value at Risk (VaR) - use MAX trick to get specific percentile row
        MAX(CASE WHEN rn = CAST(total_sims * 0.50 AS INT) THEN total_portfolio_loss END) AS VaR_50_median,
        MAX(CASE WHEN rn = CAST(total_sims * 0.75 AS INT) THEN total_portfolio_loss END) AS VaR_75,
        MAX(CASE WHEN rn = CAST(total_sims * 0.90 AS INT) THEN total_portfolio_loss END) AS VaR_90,
        MAX(CASE WHEN rn = CAST(total_sims * 0.95 AS INT) THEN total_portfolio_loss END) AS VaR_95,
        MAX(CASE WHEN rn = CAST(total_sims * 0.99 AS INT) THEN total_portfolio_loss END) AS VaR_99,
        
        -- Expected Shortfall (CVaR) - average of top 5%
        AVG(CASE WHEN rn >= total_sims * 0.95 THEN total_portfolio_loss END) AS CVaR_95,
        
        -- Foreclosure metrics
        AVG(foreclosed_balance) AS avg_foreclosed_balance,
        AVG(severely_delinquent_balance) AS avg_severe_dq_balance,
        AVG(foreclosed_count) AS avg_foreclosed_count
    FROM loss_ranked
    GROUP BY month
),

-- ============================================================================
-- PART 9: SCENARIO ANALYSIS (Stress Testing)
-- Modify transition probabilities for adverse scenarios
-- ============================================================================

stress_transition_matrix AS (
    -- Stress scenario: Double the probability of deterioration
    SELECT 
        from_state,
        to_state,
        CASE 
            WHEN to_state > from_state THEN probability * 2.0  -- 2x probability of getting worse
            WHEN to_state < from_state THEN probability * 0.5  -- 0.5x probability of improving
            ELSE probability  -- Same probability of staying
        END AS stressed_probability
    FROM complete_transition_matrix
),

normalized_stress_matrix AS (
    SELECT 
        from_state,
        to_state,
        stressed_probability / SUM(stressed_probability) OVER (PARTITION BY from_state) AS probability
    FROM stress_transition_matrix
),

-- Cumulative probabilities for stress scenario
cumulative_stress_matrix AS (
    SELECT 
        from_state,
        to_state,
        probability,
        SUM(probability) OVER (
            PARTITION BY from_state 
            ORDER BY to_state 
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS cumulative_prob
    FROM normalized_stress_matrix
),

-- Repeat Monte Carlo with stressed probabilities
stress_paths AS (
    SELECT 
        ss.loan_id,
        ss.sim_number,
        0 AS month,
        np.hidden_state AS current_state,
        np.upb,
        ss.random_seed,
        CAST(0 AS FLOAT) AS cumulative_loss,
        (ss.random_seed) % 1000 AS random_val,
        CAST(np.hidden_state AS INT) AS from_state
    FROM simulation_seeds ss
    INNER JOIN normalized_posterior np 
        ON ss.loan_id = np.loan_id
    WHERE np.hidden_state = np.observed_state
    AND ss.sim_number <= 50  -- Fewer simulations for stress (performance)
    
    UNION ALL
    
    SELECT 
        sp.loan_id,
        sp.sim_number,
        sp.month + 1,
        -- Stress scenario: 2x deterioration, 0.5x improvement
        -- Hardcoded stressed transition probabilities
        CASE 
            WHEN sp.current_state = 0 THEN  -- CURRENT (worse transitions doubled)
                CASE WHEN sp.random_val < 905 THEN 0 ELSE 1 END
            WHEN sp.current_state = 1 THEN  -- 30_DAY
                CASE 
                    WHEN sp.random_val < 243 THEN 0  -- 0.5x cure rate
                    WHEN sp.random_val < 510 THEN 1
                    ELSE 2  -- 2x escalation
                END
            WHEN sp.current_state = 2 THEN  -- 60_DAY
                CASE 
                    WHEN sp.random_val < 120 THEN 0
                    WHEN sp.random_val < 290 THEN 1
                    WHEN sp.random_val < 560 THEN 2
                    ELSE 3
                END
            WHEN sp.current_state = 3 THEN  -- 90_DAY
                CASE 
                    WHEN sp.random_val < 108 THEN 0
                    WHEN sp.random_val < 385 THEN 2
                    WHEN sp.random_val < 535 THEN 3
                    ELSE 4
                END
            WHEN sp.current_state = 4 THEN  -- 120_DAY
                CASE 
                    WHEN sp.random_val < 42 THEN 3
                    WHEN sp.random_val < 573 THEN 4
                    ELSE 5
                END
            ELSE 5
        END AS current_state,
        sp.upb,
        sp.random_seed,
        CAST(sp.cumulative_loss + 
            (SELECT loss_severity FROM state_definition WHERE state_id = sp.current_state) * 
            sp.upb * 0.01 AS FLOAT) AS cumulative_loss,
        (sp.random_seed + sp.month * 997) % 1000 AS random_val,
        CAST(sp.current_state AS INT) AS from_state
    FROM stress_paths sp
    WHERE sp.month < 12
),

stress_loss_distribution AS (
    SELECT 
        sim_number,
        month,
        SUM(cumulative_loss) AS total_portfolio_loss
    FROM stress_paths
    GROUP BY sim_number, month
),

stress_loss_ranked AS (
    SELECT 
        month,
        total_portfolio_loss,
        ROW_NUMBER() OVER (PARTITION BY month ORDER BY total_portfolio_loss) AS rn,
        COUNT(*) OVER (PARTITION BY month) AS total_sims
    FROM stress_loss_distribution
),

stress_var AS (
    SELECT 
        month,
        AVG(total_portfolio_loss) AS stress_mean_loss,
        MAX(CASE WHEN rn = CAST(total_sims * 0.95 AS INT) THEN total_portfolio_loss END) AS stress_VaR_95,
        MAX(CASE WHEN rn = CAST(total_sims * 0.99 AS INT) THEN total_portfolio_loss END) AS stress_VaR_99
    FROM stress_loss_ranked
    GROUP BY month
),

-- ============================================================================
-- PART 10: SENSITIVITY ANALYSIS
-- How sensitive are projections to transition probability changes?
-- ============================================================================

transition_sensitivity AS (
    SELECT 
        from_state,
        to_state,
        probability AS base_probability,
        -- Calculate elasticity: % change in outcome / % change in input
        -- If we increase this transition by 10%, how much does loss change?
        CASE 
            WHEN to_state = 5 THEN probability * 10  -- 10x weight on foreclosure transitions
            ELSE probability
        END AS importance_score
    FROM complete_transition_matrix
    WHERE probability > 0.01  -- Only material transitions
),

top_risk_transitions AS (
    SELECT TOP 10
        sd1.state_name AS from_state_name,
        sd2.state_name AS to_state_name,
        base_probability,
        importance_score,
        RANK() OVER (ORDER BY importance_score DESC) AS risk_rank
    FROM transition_sensitivity ts
    INNER JOIN state_definition sd1 ON ts.from_state = sd1.state_id
    INNER JOIN state_definition sd2 ON ts.to_state = sd2.state_id
    ORDER BY importance_score DESC
)

-- ============================================================================
-- FINAL OUTPUT: Multi-Dimensional Risk Dashboard
-- ============================================================================

SELECT 
    'BASE_CASE_VAR' AS metric_type,
    lp.month,
    NULL AS from_state,
    NULL AS to_state,
    lp.mean_loss,
    lp.std_dev_loss,
    lp.VaR_50_median,
    lp.VaR_75,
    lp.VaR_90,
    lp.VaR_95,
    lp.VaR_99,
    lp.CVaR_95,
    NULL AS stress_VaR_95,
    NULL AS risk_rank
FROM loss_percentiles lp

UNION ALL

SELECT 
    'STRESS_SCENARIO_VAR',
    sv.month,
    NULL,
    NULL,
    sv.stress_mean_loss,
    NULL,
    NULL,
    NULL,
    NULL,
    sv.stress_VaR_95,
    sv.stress_VaR_99,
    NULL,
    sv.stress_VaR_95,
    NULL
FROM stress_var sv

UNION ALL

SELECT 
    'TOP_RISK_TRANSITIONS',
    NULL,
    trt.from_state_name,
    trt.to_state_name,
    trt.base_probability,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    trt.risk_rank
FROM top_risk_transitions trt

ORDER BY metric_type, month, risk_rank;
