# 4-Day SQL Crash Course: Zero to HackerEarth Ready

## The 5 Patterns That Matter

**Easy tier (15-20 min):**
1. Multi-table JOINs with aggregation

**Hard tier (45-60 min):**
2. Window functions (ROW_NUMBER, RANK, LAG/LEAD)
3. CTEs (Common Table Expressions)

**Extremely hard tier (45-60 min):**
4. Gaps and Islands (consecutive sequences)
5. Recursive CTEs (hierarchies)

Master these 5, and you can solve 90% of HackerEarth SQL problems.

---

## DAY 1 (TODAY - TUESDAY): Foundation + Window Functions
**Goal:** Get comfortable with JOINs and learn window functions  
**Time commitment:** 3 hours  
**Platform:** LeetCode SQL (free tier)

### Morning Block (90 minutes)
**Setup (10 min):**
- Go to https://leetcode.com/problemset/database/
- Create free account
- Filter: Difficulty = Easy

**Drill - Pattern 1: JOINs + GROUP BY (80 min):**

Solve these 5 problems IN ORDER:
1. [595. Big Countries](https://leetcode.com/problems/big-countries/) (warm-up)
2. [1757. Recyclable and Low Fat Products](https://leetcode.com/problems/recyclable-and-low-fat-products/)
3. [1683. Invalid Tweets](https://leetcode.com/problems/invalid-tweets/)
4. [1378. Replace Employee ID](https://leetcode.com/problems/replace-employee-id-with-the-unique-identifier/) (first JOIN)
5. [1581. Customer Who Visited](https://leetcode.com/problems/customer-who-visited-but-did-not-make-any-transactions/) (JOIN with aggregation)

**Rules:**
- Try for 15 minutes before looking at solution
- When stuck, read solution, understand it, then CLOSE IT and rewrite from memory
- Run against test cases until all pass

### Afternoon Block (90 minutes)
**Drill - Pattern 2: Window Functions (90 min):**

Window functions are THE differentiator between easy and hard questions.

**Core syntax to memorize:**
```sql
-- Ranking functions
ROW_NUMBER() OVER (PARTITION BY category ORDER BY value DESC)
RANK() OVER (ORDER BY score DESC)
DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC)

-- Offset functions
LAG(column, 1) OVER (ORDER BY date)
LEAD(column, 1) OVER (ORDER BY date)

-- Aggregate functions
SUM(amount) OVER (PARTITION BY customer ORDER BY date)
AVG(score) OVER (PARTITION BY class ORDER BY test_date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
```

**LeetCode problems (solve in order):**
1. [176. Second Highest Salary](https://leetcode.com/problems/second-highest-salary/) (LIMIT + OFFSET approach first)
2. [177. Nth Highest Salary](https://leetcode.com/problems/nth-highest-salary/) (window function approach)
3. [178. Rank Scores](https://leetcode.com/problems/rank-scores/) (DENSE_RANK)
4. [184. Department Highest Salary](https://leetcode.com/problems/department-highest-salary/) (RANK + filter)

**End of day checkpoint:**
- Can you write a ROW_NUMBER() query from scratch? (Try it)
- Can you explain the difference between RANK() and DENSE_RANK()? (Write it out)

---

## DAY 2 (WEDNESDAY): CTEs + Gaps and Islands
**Goal:** Master CTEs and learn the gaps-and-islands pattern  
**Time commitment:** 4 hours  
**Platform:** LeetCode SQL

### Morning Block (2 hours)
**Drill - Pattern 3: CTEs (Common Table Expressions)**

**Syntax template to memorize:**
```sql
WITH cte_name AS (
  SELECT column1, column2
  FROM table
  WHERE condition
),
second_cte AS (
  SELECT cte_name.column1, other_table.column3
  FROM cte_name
  JOIN other_table ON ...
)
SELECT *
FROM second_cte
WHERE ...;
```

**Why CTEs matter:**
- Break complex queries into readable steps
- Required for recursive queries (tomorrow)
- HackerEarth hard questions almost always need multi-CTE approach

**LeetCode problems:**
1. [1484. Group Sold Products By The Date](https://leetcode.com/problems/group-sold-products-by-the-date/)
2. [1341. Movie Rating](https://leetcode.com/problems/movie-rating/) (multiple CTEs)
3. [1204. Last Person to Fit in the Bus](https://leetcode.com/problems/last-person-to-fit-in-the-bus/) (running total with CTE)
4. [550. Game Play Analysis IV](https://leetcode.com/problems/game-play-analysis-iv/) (self-join + CTE)

### Afternoon Block (2 hours)
**Drill - Pattern 4: Gaps and Islands**

This is THE pattern for "extremely hard" questions. It appears constantly.

**The problem:** Find consecutive sequences in data.

**Example:**
```
loan_id | month     | status
--------|-----------|--------
1       | 2024-01   | DQ
1       | 2024-02   | DQ
1       | 2024-03   | DQ
1       | 2024-04   | Current
1       | 2024-05   | Current
1       | 2024-06   | DQ
```

**Question:** Find all periods of consecutive delinquency for each loan.

**The technique (ROW_NUMBER difference method):**

```sql
WITH numbered AS (
  SELECT
    loan_id,
    month,
    ROW_NUMBER() OVER (ORDER BY loan_id, month) AS global_rn,
    ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY month) AS loan_rn
  FROM loans
  WHERE status = 'DQ'
),
islands AS (
  SELECT
    loan_id,
    month,
    global_rn - loan_rn AS island_id  -- Key insight: consecutive rows have same difference
  FROM numbered
)
SELECT
  loan_id,
  MIN(month) AS delinquency_start,
  MAX(month) AS delinquency_end,
  COUNT(*) AS consecutive_months
FROM islands
GROUP BY loan_id, island_id
ORDER BY loan_id, delinquency_start;
```

**Why this works:**
- For consecutive rows, `global_rn - loan_rn` stays constant
- When there's a gap, the difference changes
- Same difference = same island

**Practice problems:**
1. [180. Consecutive Numbers](https://leetcode.com/problems/consecutive-numbers/) (easiest gaps-and-islands)
2. [601. Human Traffic of Stadium](https://leetcode.com/problems/human-traffic-of-stadium/) (classic gaps-and-islands)
3. Create your own: "Find all employees who worked 3+ consecutive days"

**Critical:** Spend time UNDERSTANDING why the ROW_NUMBER difference works. Draw it out on paper with sample data.

---

## DAY 3 (THURSDAY): Recursive CTEs + Full Simulation
**Goal:** Learn recursive CTEs, then test yourself under real conditions  
**Time commitment:** 5 hours  

### Morning Block (2 hours)
**Drill - Pattern 5: Recursive CTEs**

**The problem:** Traversing hierarchies or chains.

**Examples:**
- Employee reporting structure (who reports to whom)
- Loan servicing transfers (loan moved from servicer A → B → C)
- Product categories (Category → Subcategory → Item)

**Syntax template (memorize this):**
```sql
WITH RECURSIVE hierarchy AS (
  -- ANCHOR: Starting point
  SELECT id, parent_id, name, 1 AS level
  FROM table
  WHERE parent_id IS NULL  -- Root nodes
  
  UNION ALL
  
  -- RECURSIVE: Each subsequent level
  SELECT t.id, t.parent_id, t.name, h.level + 1
  FROM table t
  INNER JOIN hierarchy h ON t.parent_id = h.id
)
SELECT * FROM hierarchy;
```

**Key parts:**
1. **ANCHOR** - Base case (WHERE to start)
2. **UNION ALL** - Must be UNION ALL, not UNION
3. **RECURSIVE reference** - CTE calls itself
4. **Termination** - Stops when no more rows match the JOIN

**LeetCode problems:**
1. [1270. All People Report to Given Manager](https://leetcode.com/problems/all-people-report-to-the-given-manager/) (3-level hierarchy)

**Note:** LeetCode has limited recursive CTE problems. Use this pattern instead:

**Practice exercise (do this in SQL Fiddle):**
```sql
-- Create sample hierarchy
CREATE TABLE employees (
  id INT,
  name VARCHAR(50),
  manager_id INT
);

INSERT INTO employees VALUES
(1, 'CEO', NULL),
(2, 'VP Sales', 1),
(3, 'VP Eng', 1),
(4, 'Sales Manager', 2),
(5, 'Engineer', 3),
(6, 'Junior Dev', 5);

-- Write recursive query to show full org chart with levels
```

**Write this query from scratch 3 times** until you can do it without looking.

### Afternoon Block (3 hours)
**FULL SIMULATION TEST**

This is the most important part of your prep.

**Setup:**
1. Go to https://leetcode.com/problemset/database/
2. Pick 3 problems WITHOUT looking at them first:
   - 1 Easy
   - 1 Medium  
   - 1 Hard
3. Set timer for 2 hours
4. Solve all 3 under test conditions:
   - No searching for solutions
   - No looking at hints
   - If stuck after 30 min, move to next question
   - Come back at the end if time remains

**Suggested problems for simulation:**
- Easy: [1965. Employees With Missing Information](https://leetcode.com/problems/employees-with-missing-information/)
- Medium: [1174. Immediate Food Delivery II](https://leetcode.com/problems/immediate-food-delivery-ii/)
- Hard: [262. Trips and Users](https://leetcode.com/problems/trips-and-users/)

**After the 2 hours:**
- Review solutions for problems you didn't solve
- Understand WHY you got stuck
- Identify which pattern you missed
- Write notes on what to remember

---

## DAY 4 (FRIDAY): Test Day
**Goal:** Take the real test, well-rested and prepared

### Morning Routine (before test)
- Light breakfast, hydration
- 15-minute warm-up: Write one window function query from memory
- Review your notes from Day 3 simulation
- Deep breath

### Take the HackerEarth Practice Test (30 min before real test)
**Do this FIRST**, before the real test:
- Familiarize with HackerEarth interface
- Check webcam/audio
- See how SQL editor works
- Understand how to submit

### Take the Real Test (2 hours)
**Strategy:**
1. Read all 3 questions first (5 min)
2. Easy question (15-20 min) - clean, correct, done
3. Hard question (45-60 min) - plan first, code second
4. Extremely hard (remaining time) - recognize the pattern, execute

**Pattern recognition quick reference:**
- "Find consecutive..." → Gaps and islands (ROW_NUMBER difference)
- "Hierarchy / chain / path..." → Recursive CTE
- "Rank / nth highest / top N per category..." → Window functions
- "Multiple tables with conditions..." → CTE + JOINs

**Time management:**
- Don't spend >60 min on any single question
- Partial correctness > zero on extremely hard
- At minute 110, submit whatever you have

---

## Critical Resources

**LeetCode SQL:** https://leetcode.com/problemset/database/
**SQL Fiddle:** http://sqlfiddle.com/
**Window Functions Cheat Sheet:** https://learnsql.com/blog/sql-window-functions-cheat-sheet/
**Recursive CTE Tutorial:** https://www.sqlservertutorial.net/sql-server-basics/sql-server-recursive-cte/

---

## The Honest Truth

You're starting from zero with 4 days. This is an aggressive plan. But:

1. **HackerEarth tests are pattern-based** - not "know all SQL," but "know these 5 patterns"
2. **Muscle memory beats theory** - solve 20 real problems > read 100 pages of docs
3. **The simulation on Day 3 is make-or-break** - it tells you if you're ready
4. **Easy + Hard questions = 70% of the score** - you can pass without solving extremely hard perfectly

**You can do this.** Four focused days is enough if you execute the plan.

Start today. Start with LeetCode. Start with the Easy problems. Build momentum.
