# Rice Park SQL Practice - Using YOUR Mortgage Data

## Your Database Schema

**Tables:**
- `loan_master` - Static loan attributes (FICO, state, property type, original amount)
- `loan_snapshots` - Monthly performance snapshots (UPB, DQ status, payments, loan age)
- `pools` - Pool static data
- `pool_monthly_activity` - Pool performance over time
- `subservicers` - Servicer info
- `remittances` - Payment history
- `portfolio_of_record` - Portfolio assignments

**Key fields in loan_snapshots:**
- `loan_id`, `as_of_date` (monthly)
- `dq_status` (CURRENT, 30_DAY, 60_DAY, etc.)
- `days_past_due`
- `upb` (unpaid principal balance)
- `scheduled_pi_paid`, `actual_pi_paid`
- `loan_age` (months since origination)

---

## PATTERN 1: Window Functions (Most Common)

### Exercise 1.1: Find Each Loan's Highest Delinquency Status
**Business question:** What's the worst delinquency each loan has ever experienced?

```sql
SELECT 
    loan_id,
    MAX(days_past_due) AS max_days_delinquent,
    -- Get the status when it was worst
    FIRST_VALUE(dq_status) OVER (
        PARTITION BY loan_id 
        ORDER BY days_past_due DESC
    ) AS worst_status
FROM loan_snapshots
GROUP BY loan_id;
```

**Pattern learned:** Window functions vs GROUP BY, FIRST_VALUE

---

### Exercise 1.2: Month-Over-Month UPB Change
**Business question:** For each loan, show how much the balance changed each month.

```sql
SELECT 
    loan_id,
    as_of_date,
    upb AS current_upb,
    LAG(upb, 1) OVER (PARTITION BY loan_id ORDER BY as_of_date) AS prior_month_upb,
    upb - LAG(upb, 1) OVER (PARTITION BY loan_id ORDER BY as_of_date) AS upb_change,
    -- Negative = principal paydown, Positive = fees added
    CASE 
        WHEN upb - LAG(upb, 1) OVER (PARTITION BY loan_id ORDER BY as_of_date) < 0 
        THEN 'Paydown'
        WHEN upb - LAG(upb, 1) OVER (PARTITION BY loan_id ORDER BY as_of_date) > 0 
        THEN 'Balance Increase'
        ELSE 'No Change'
    END AS change_type
FROM loan_snapshots
ORDER BY loan_id, as_of_date;
```

**Pattern learned:** LAG/LEAD for comparing rows over time

---

### Exercise 1.3: Rank Loans by Current UPB Within Each Pool
**Business question:** For the most recent month, what are the top 5 largest loans in each pool?

```sql
WITH latest_snapshot AS (
    SELECT *
    FROM loan_snapshots
    WHERE as_of_date = (SELECT MAX(as_of_date) FROM loan_snapshots)
)
SELECT 
    pool_id,
    loan_id,
    upb,
    RANK() OVER (PARTITION BY pool_id ORDER BY upb DESC) AS size_rank
FROM latest_snapshot
INNER JOIN loan_master ON latest_snapshot.loan_id = loan_master.loan_id
WHERE RANK() OVER (PARTITION BY pool_id ORDER BY upb DESC) <= 5
ORDER BY pool_id, size_rank;
```

**Pattern learned:** RANK vs ROW_NUMBER, filtering ranked results

---

### Exercise 1.4: Running Total of Principal Paid
**Business question:** For each loan, show cumulative principal paydown over time.

```sql
SELECT 
    loan_id,
    as_of_date,
    actual_pi_paid,
    SUM(actual_pi_paid) OVER (
        PARTITION BY loan_id 
        ORDER BY as_of_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_pi_paid
FROM loan_snapshots
ORDER BY loan_id, as_of_date;
```

**Pattern learned:** Running totals with ROWS BETWEEN

---

## PATTERN 2: CTEs (Breaking Complex Logic into Steps)

### Exercise 2.1: Find Loans That Cured from Delinquency
**Business question:** Which loans were 60+ days delinquent but are now current?

```sql
WITH worst_status AS (
    -- Step 1: Find each loan's worst historical status
    SELECT 
        loan_id,
        MAX(days_past_due) AS max_dpd
    FROM loan_snapshots
    GROUP BY loan_id
),
current_status AS (
    -- Step 2: Get most recent status
    SELECT 
        loan_id,
        dq_status,
        days_past_due
    FROM loan_snapshots
    WHERE as_of_date = (SELECT MAX(as_of_date) FROM loan_snapshots)
)
-- Step 3: Find loans that cured
SELECT 
    w.loan_id,
    w.max_dpd AS worst_dpd_ever,
    c.dq_status AS current_status,
    c.days_past_due AS current_dpd
FROM worst_status w
INNER JOIN current_status c ON w.loan_id = c.loan_id
WHERE w.max_dpd >= 60  -- Was seriously delinquent
  AND c.dq_status = 'CURRENT'  -- Now current
ORDER BY w.max_dpd DESC;
```

**Pattern learned:** Multi-step CTEs, combining historical and current data

---

### Exercise 2.2: Pool-Level Delinquency Rate by Month
**Business question:** For each pool and month, what % of loans are 30+ days delinquent?

```sql
WITH monthly_pool_stats AS (
    SELECT 
        lm.pool_id,
        ls.as_of_date,
        COUNT(*) AS total_loans,
        SUM(CASE WHEN ls.days_past_due >= 30 THEN 1 ELSE 0 END) AS dq_loans,
        SUM(ls.upb) AS total_upb,
        SUM(CASE WHEN ls.days_past_due >= 30 THEN ls.upb ELSE 0 END) AS dq_upb
    FROM loan_snapshots ls
    INNER JOIN loan_master lm ON ls.loan_id = lm.loan_id
    GROUP BY lm.pool_id, ls.as_of_date
)
SELECT 
    pool_id,
    as_of_date,
    total_loans,
    dq_loans,
    CAST(dq_loans AS FLOAT) / total_loans * 100 AS dq_rate_pct,
    CAST(dq_upb AS FLOAT) / total_upb * 100 AS dq_upb_pct
FROM monthly_pool_stats
ORDER BY pool_id, as_of_date;
```

**Pattern learned:** Aggregations with CASE, calculated metrics

---

## PATTERN 3: Gaps and Islands (CRITICAL - Most Likely "Extremely Hard")

### Exercise 3.1: Find All Consecutive Delinquency Periods
**Business question:** For each loan, identify all periods of consecutive delinquency (30+ days). Show start date, end date, duration.

**This is THE pattern Rice Park will test.**

```sql
-- Step 1: Filter to delinquent months only
WITH delinquent_months AS (
    SELECT 
        loan_id,
        as_of_date,
        dq_status,
        days_past_due
    FROM loan_snapshots
    WHERE days_past_due >= 30
),
-- Step 2: Number all rows two different ways
numbered AS (
    SELECT 
        loan_id,
        as_of_date,
        dq_status,
        days_past_due,
        ROW_NUMBER() OVER (ORDER BY loan_id, as_of_date) AS global_rn,
        ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY as_of_date) AS loan_rn
    FROM delinquent_months
),
-- Step 3: Calculate island_id (consecutive rows have same difference)
islands AS (
    SELECT 
        loan_id,
        as_of_date,
        dq_status,
        days_past_due,
        global_rn - loan_rn AS island_id
    FROM numbered
)
-- Step 4: Collapse islands into periods
SELECT 
    loan_id,
    MIN(as_of_date) AS delinquency_start,
    MAX(as_of_date) AS delinquency_end,
    COUNT(*) AS months_delinquent,
    MAX(days_past_due) AS worst_dpd_in_period
FROM islands
GROUP BY loan_id, island_id
HAVING COUNT(*) >= 3  -- Only show periods of 3+ consecutive months
ORDER BY loan_id, delinquency_start;
```

**KEY INSIGHT:** The `global_rn - loan_rn` difference stays constant for consecutive months. When there's a gap, the difference changes.

**Pattern learned:** Gaps-and-islands ROW_NUMBER difference method

---

### Exercise 3.2: Find Loans That Had Multiple Delinquency Episodes
**Business question:** Which loans went delinquent, cured, then went delinquent again?

```sql
-- Use the islands query from 3.1, then count episodes per loan
WITH delinquent_months AS (
    SELECT loan_id, as_of_date, days_past_due
    FROM loan_snapshots
    WHERE days_past_due >= 60  -- 60+ days = serious
),
numbered AS (
    SELECT 
        loan_id, as_of_date, days_past_due,
        ROW_NUMBER() OVER (ORDER BY loan_id, as_of_date) AS global_rn,
        ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY as_of_date) AS loan_rn
    FROM delinquent_months
),
islands AS (
    SELECT loan_id, as_of_date, global_rn - loan_rn AS island_id
    FROM numbered
),
episodes AS (
    SELECT 
        loan_id,
        MIN(as_of_date) AS episode_start,
        MAX(as_of_date) AS episode_end,
        COUNT(*) AS months_in_episode
    FROM islands
    GROUP BY loan_id, island_id
)
-- Find loans with multiple episodes
SELECT 
    loan_id,
    COUNT(*) AS num_episodes,
    MIN(episode_start) AS first_episode_start,
    MAX(episode_end) AS last_episode_end
FROM episodes
GROUP BY loan_id
HAVING COUNT(*) >= 2  -- Multiple episodes
ORDER BY num_episodes DESC;
```

**Pattern learned:** Extending gaps-and-islands to identify patterns of behavior

---

## PATTERN 4: Self-Joins (Comparing Periods)

### Exercise 4.1: Find Status Transitions
**Business question:** Identify all month-to-month transitions from CURRENT to 30_DAY (new delinquencies).

```sql
SELECT 
    curr.loan_id,
    prev.as_of_date AS prior_month,
    curr.as_of_date AS current_month,
    prev.dq_status AS was_status,
    curr.dq_status AS now_status,
    curr.days_past_due AS current_dpd
FROM loan_snapshots curr
INNER JOIN loan_snapshots prev 
    ON curr.loan_id = prev.loan_id
   AND curr.as_of_date = DATEADD(MONTH, 1, prev.as_of_date)
WHERE prev.dq_status = 'CURRENT'
  AND curr.dq_status IN ('30_DAY', '60_DAY', '90_DAY')
ORDER BY curr.as_of_date DESC, curr.loan_id;
```

**Pattern learned:** Self-join with date offset for period-over-period analysis

---

### Exercise 4.2: Find Loans with Payment Shortfalls
**Business question:** Which loans have months where actual payment < scheduled payment?

```sql
SELECT 
    loan_id,
    as_of_date,
    scheduled_pi_paid,
    actual_pi_paid,
    scheduled_pi_paid - actual_pi_paid AS shortfall,
    CAST((scheduled_pi_paid - actual_pi_paid) AS FLOAT) / scheduled_pi_paid * 100 AS shortfall_pct
FROM loan_snapshots
WHERE actual_pi_paid < scheduled_pi_paid
  AND scheduled_pi_paid > 0  -- Avoid divide by zero
ORDER BY shortfall DESC;
```

**Pattern learned:** Identifying exceptions with WHERE filters

---

## PATTERN 5: Recursive CTEs (Hierarchies/Chains)

### Exercise 5.1: Trace Servicer Transfers
**Business question:** If a loan transferred from servicer A → B → C, show the full chain.

**Note:** Your data might not have transfer history in subservicers table. If not, this is conceptual practice:

```sql
-- Conceptual example (would need servicer_transfers table)
-- Shows the recursive CTE pattern for Rice Park test

WITH RECURSIVE servicer_chain AS (
    -- ANCHOR: Starting servicer for each loan
    SELECT 
        loan_id,
        subservicer_id AS current_servicer,
        subservicer_id AS original_servicer,
        1 AS hop_number
    FROM loan_master
    
    UNION ALL
    
    -- RECURSIVE: Each subsequent transfer
    SELECT 
        t.loan_id,
        t.to_servicer_id AS current_servicer,
        c.original_servicer,
        c.hop_number + 1
    FROM servicer_transfers t
    INNER JOIN servicer_chain c 
        ON t.loan_id = c.loan_id 
       AND t.from_servicer_id = c.current_servicer
)
SELECT 
    loan_id,
    original_servicer,
    current_servicer,
    hop_number AS total_transfers
FROM servicer_chain
WHERE hop_number = (
    SELECT MAX(hop_number) 
    FROM servicer_chain sc2 
    WHERE sc2.loan_id = servicer_chain.loan_id
)
ORDER BY total_transfers DESC;
```

**Pattern learned:** Recursive CTE structure (ANCHOR + UNION ALL + RECURSIVE)

**If you don't have transfer data:** Practice this pattern conceptually, understand the structure. Rice Park might test it with org hierarchies or loan modification chains.

---

## 4-Day Practice Schedule (Updated for YOUR Data)

### DAY 1 (Today - Tuesday): Window Functions
**Time: 3 hours**

1. **Run Exercises 1.1 - 1.4** in your local database
2. **Modify them:** Change filters, add different calculations
3. **Key concepts to master:**
   - LAG/LEAD for month-over-month comparisons
   - ROW_NUMBER vs RANK vs DENSE_RANK
   - Running totals with ROWS BETWEEN
   - When to filter with WHERE vs HAVING

**Success metric:** Can you write a window function query from scratch without looking?

---

### DAY 2 (Wednesday): CTEs + Gaps-and-Islands
**Time: 4 hours**

**Morning (2 hours):**
- **Run Exercises 2.1 - 2.2** (CTEs)
- Practice breaking complex logic into readable steps
- Build your own: "Find average UPB by property type and state"

**Afternoon (2 hours):**
- **Run Exercise 3.1** (Gaps-and-islands) - THIS IS CRITICAL
- Study the ROW_NUMBER difference method until it clicks
- **Modify it:** Find consecutive periods of CURRENT status
- **Challenge:** Find loans with gaps in data (missing months)

**Success metric:** Can you explain WHY `global_rn - loan_rn` identifies islands?

---

### DAY 3 (Thursday): Self-Joins + Full Simulation
**Time: 5 hours**

**Morning (2 hours):**
- **Run Exercises 4.1 - 4.2** (Self-joins)
- Practice: Find loans where UPB increased month-over-month
- Understand recursive CTE structure (even if you can't test it)

**Afternoon (3 hours): FULL 2-HOUR SIMULATION**

**Create 3 realistic problems for yourself:**

**Easy (20 min):**
"List all loans in Pool_E with current UPB > $500k, show borrower FICO and property state from loan_master."

**Hard (60 min):**
"For each pool, calculate the % of loans that are currently 60+ days delinquent. Include total UPB and delinquent UPB."

**Extremely Hard (40 min):**
"Find all loans that had at least one period of 3+ consecutive delinquent months in 2025, then show each delinquency period with start/end dates and max DPD."

**Set a 2-hour timer. Solve all 3. No cheating.**

**After timer ends:** Review, identify what you struggled with, drill that pattern again.

---

### DAY 4 (Friday): TEST DAY

**Morning prep:**
- Review your notes from Day 3 simulation
- Run one warm-up query (pick any from above)
- Take HackerEarth practice test
- Deep breath

**Take the real test.**

---

## Quick Reference for Test Day

**Pattern Recognition:**
- "Consecutive periods" → Gaps-and-islands (ROW_NUMBER difference)
- "Month-over-month change" → LAG/LEAD
- "Top N per category" → ROW_NUMBER + WHERE rn <= N
- "Running total" → SUM() OVER (ORDER BY ... ROWS BETWEEN)
- "Hierarchy/chain" → Recursive CTE
- "Complex multi-step" → CTEs

**Mortgage domain quick tips:**
- DQ status: CURRENT < 30_DAY < 60_DAY < 90_DAY < 120_DAY
- UPB = Unpaid Principal Balance (current loan size)
- Days_past_due = 0 means current, 30 = one payment missed, etc.
- Cure = transition from DQ back to CURRENT
- Pool = group of loans

---

## START NOW

**Your first task (next 90 minutes):**

1. Open Azure Data Studio
2. Connect to `rice_park_practice` database
3. Run Exercise 1.1 (Highest Delinquency)
4. Run Exercise 1.2 (UPB Changes)
5. Modify Exercise 1.2 to show payment shortfalls instead

**Then come back and tell me:**
- Which query was hardest?
- What pattern confused you?
- What you learned

This data is PERFECT for Rice Park prep. You're practicing exactly what they'll test.

**Go. Run the first query. Build momentum.**
