USE rice_park_practice;

-- ULTIMATE: Markov Chain State Transition Matrix with Forward Loss Projection (CORRECTED)
-- Build transition probabilities, project future states, calculate absorption times

WITH 
-- Step 1: Define all possible states
state_definition AS (
    SELECT state_id, state_name FROM (VALUES 
        (0, 'CURRENT'),
        (1, '30_DAY'),
        (2, '60_DAY'),
        (3, '90_DAY'),
        (4, '120_DAY'),
        (5, 'FORECLOSURE')
    ) AS states(state_id, state_name)
),

-- Step 2: Map each loan snapshot to state IDs
loan_states AS (
    SELECT 
        loan_id,
        as_of_date,
        CASE dq_status
            WHEN 'CURRENT' THEN 0
            WHEN '30_DAY' THEN 1
            WHEN '60_DAY' THEN 2
            WHEN '90_DAY' THEN 3
            WHEN '120_DAY' THEN 4
            WHEN 'FORECLOSURE' THEN 5
            ELSE 0
        END AS current_state,
        LEAD(CASE dq_status
            WHEN 'CURRENT' THEN 0
            WHEN '30_DAY' THEN 1
            WHEN '60_DAY' THEN 2
            WHEN '90_DAY' THEN 3
            WHEN '120_DAY' THEN 4
            WHEN 'FORECLOSURE' THEN 5
            ELSE 0
        END, 1) OVER (PARTITION BY loan_id ORDER BY as_of_date) AS next_state
    FROM dbo.loan_snapshots
),

-- Step 3: Count ALL transitions
transition_counts AS (
    SELECT 
        current_state AS from_state,
        next_state AS to_state,
        COUNT(*) AS transition_count
    FROM loan_states
    WHERE next_state IS NOT NULL
    GROUP BY current_state, next_state
),

-- Step 4: Calculate transition PROBABILITIES
transition_matrix AS (
    SELECT 
        tc.from_state,
        tc.to_state,
        tc.transition_count,
        SUM(tc.transition_count) OVER (PARTITION BY tc.from_state) AS total_from_state,
        CAST(tc.transition_count AS FLOAT) / 
            SUM(tc.transition_count) OVER (PARTITION BY tc.from_state) AS probability,
        SQRT(
            (CAST(tc.transition_count AS FLOAT) / 
             SUM(tc.transition_count) OVER (PARTITION BY tc.from_state)) *
            (1 - CAST(tc.transition_count AS FLOAT) / 
             SUM(tc.transition_count) OVER (PARTITION BY tc.from_state)) /
            SUM(tc.transition_count) OVER (PARTITION BY tc.from_state)
        ) AS standard_error
    FROM transition_counts tc
),

-- Step 5: Complete matrix (fill missing transitions with 0)
complete_matrix AS (
    SELECT 
        s1.state_id AS from_state,
        s2.state_id AS to_state,
        s1.state_name AS from_state_name,
        s2.state_name AS to_state_name,
        ISNULL(tm.probability, 0) AS probability,
        ISNULL(tm.standard_error, 0) AS standard_error,
        ISNULL(tm.transition_count, 0) AS observed_transitions
    FROM state_definition s1
    CROSS JOIN state_definition s2
    LEFT JOIN transition_matrix tm 
        ON s1.state_id = tm.from_state 
        AND s2.state_id = tm.to_state
),

-- Step 6: Current portfolio distribution
current_distribution AS (
    SELECT 
        current_state AS state_id,
        COUNT(*) AS loan_count,
        CAST(COUNT(*) AS FLOAT) / SUM(COUNT(*)) OVER () AS proportion
    FROM loan_states
    WHERE as_of_date = (SELECT MAX(as_of_date) FROM loan_states)
    GROUP BY current_state
),

-- Step 7: 1 month forward projection
projection_1mo AS (
    SELECT 
        cm.to_state AS state_id,
        sd.state_name,
        SUM(ISNULL(cd.proportion, 0) * cm.probability) AS projected_proportion_1mo,
        SQRT(SUM(POWER(ISNULL(cd.proportion, 0) * cm.standard_error, 2))) AS projection_std_error
    FROM complete_matrix cm
    LEFT JOIN current_distribution cd ON cm.from_state = cd.state_id
    INNER JOIN state_definition sd ON cm.to_state = sd.state_id
    GROUP BY cm.to_state, sd.state_name
),

-- Step 8: 3 month forward projection
projection_intermediate AS (
    SELECT 
        cm.to_state AS state_id,
        sd.state_name,
        SUM(p1.projected_proportion_1mo * cm.probability) AS projected_proportion_2mo
    FROM complete_matrix cm
    INNER JOIN projection_1mo p1 ON cm.from_state = p1.state_id
    INNER JOIN state_definition sd ON cm.to_state = sd.state_id
    GROUP BY cm.to_state, sd.state_name
),

projection_3mo AS (
    SELECT 
        cm.to_state AS state_id,
        sd.state_name,
        SUM(pi.projected_proportion_2mo * cm.probability) AS projected_proportion_3mo
    FROM complete_matrix cm
    INNER JOIN projection_intermediate pi ON cm.from_state = pi.state_id
    INNER JOIN state_definition sd ON cm.to_state = sd.state_id
    GROUP BY cm.to_state, sd.state_name
),

-- Step 9: Absorbing states
absorbing_states AS (
    SELECT 
        from_state,
        from_state_name,
        probability AS self_loop_probability,
        CASE 
            WHEN probability >= 0.95 THEN 'ABSORBING'
            WHEN probability >= 0.75 THEN 'HIGHLY_STICKY'
            WHEN probability >= 0.50 THEN 'MODERATELY_STICKY'
            ELSE 'TRANSIENT'
        END AS state_type
    FROM complete_matrix
    WHERE from_state = to_state
),

-- Step 10A: Find foreclosure date for each loan-state observation (FIXED)
foreclosure_dates AS (
    SELECT 
        ls.loan_id,
        ls.current_state,
        ls.as_of_date,
        (SELECT MIN(ls2.as_of_date)
         FROM loan_states ls2
         WHERE ls2.loan_id = ls.loan_id
           AND ls2.current_state = 5
           AND ls2.as_of_date > ls.as_of_date
        ) AS foreclosure_date
    FROM loan_states ls
    WHERE ls.current_state < 5
),

-- Step 10B: Calculate months to foreclosure (FIXED)
time_to_foreclosure AS (
    SELECT 
        current_state,
        loan_id,
        as_of_date,
        foreclosure_date,
        DATEDIFF(MONTH, as_of_date, foreclosure_date) AS months_to_foreclosure,
        CASE WHEN foreclosure_date IS NOT NULL THEN 1 ELSE 0 END AS did_foreclose
    FROM foreclosure_dates
),

-- Step 10C: Aggregate (FIXED)
absorption_risk AS (
    SELECT 
        ttf.current_state,
        sd.state_name,
        AVG(ttf.months_to_foreclosure) AS avg_months_to_foreclosure,
        COUNT(*) AS sample_size,
        CAST(SUM(ttf.did_foreclose) AS FLOAT) / COUNT(*) * 100 AS eventual_foreclosure_rate_pct
    FROM time_to_foreclosure ttf
    INNER JOIN state_definition sd ON ttf.current_state = sd.state_id
    GROUP BY ttf.current_state, sd.state_name
)

-- Step 11: FINAL OUTPUT
SELECT 
    'CURRENT_DISTRIBUTION' AS metric_type,
    cd.state_id,
    sd.state_name,
    cd.loan_count AS current_count,
    cd.proportion * 100 AS current_pct,
    NULL AS projected_1mo_pct,
    NULL AS projected_3mo_pct,
    NULL AS conf_interval_95_lower,
    NULL AS conf_interval_95_upper,
    NULL AS state_type,
    NULL AS avg_months_to_foreclosure,
    NULL AS eventual_foreclosure_rate_pct
FROM current_distribution cd
INNER JOIN state_definition sd ON cd.state_id = sd.state_id

UNION ALL

SELECT 
    'PROJECTION' AS metric_type,
    p1.state_id,
    p1.state_name,
    NULL,
    NULL,
    p1.projected_proportion_1mo * 100 AS projected_1mo_pct,
    p3.projected_proportion_3mo * 100 AS projected_3mo_pct,
    (p1.projected_proportion_1mo - 1.96 * p1.projection_std_error) * 100 AS conf_interval_95_lower,
    (p1.projected_proportion_1mo + 1.96 * p1.projection_std_error) * 100 AS conf_interval_95_upper,
    NULL,
    NULL,
    NULL
FROM projection_1mo p1
INNER JOIN projection_3mo p3 ON p1.state_id = p3.state_id

UNION ALL

SELECT 
    'ABSORPTION_ANALYSIS' AS metric_type,
    ar.current_state AS state_id,
    ar.state_name,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    abs_st.state_type,
    ar.avg_months_to_foreclosure,
    ar.eventual_foreclosure_rate_pct
FROM absorption_risk ar
INNER JOIN absorbing_states abs_st ON ar.current_state = abs_st.from_state

ORDER BY metric_type, state_id;
