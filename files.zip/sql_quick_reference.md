# SQL Pattern Quick Reference (Print This For Test Day)

## Pattern Recognition (Which pattern to use?)

| Question Contains... | Pattern | Tool |
|---------------------|---------|------|
| "consecutive", "streak", "sequence" | Gaps and Islands | ROW_NUMBER difference |
| "hierarchy", "tree", "path", "chain" | Recursive CTE | WITH RECURSIVE |
| "rank", "top N per", "nth highest" | Window Functions | ROW_NUMBER, RANK |
| "running total", "cumulative" | Window Functions | SUM() OVER |
| "previous/next row", "lag/lead" | Window Functions | LAG, LEAD |
| Multiple tables, complex logic | CTEs | WITH cte_name AS |

---

## Pattern 1: Window Functions (Most Common)

```sql
-- Ranking
ROW_NUMBER() OVER (PARTITION BY category ORDER BY value DESC) AS rn
RANK() OVER (ORDER BY score DESC) AS rank
DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS dense_rank

-- Offset
LAG(column, 1) OVER (ORDER BY date) AS prev_value
LEAD(column, 1) OVER (ORDER BY date) AS next_value

-- Running aggregates
SUM(amount) OVER (PARTITION BY customer ORDER BY date) AS running_total
AVG(score) OVER (ORDER BY date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
```

**When to filter after window:**
```sql
WITH ranked AS (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY id ORDER BY date DESC) AS rn
  FROM table
)
SELECT * FROM ranked WHERE rn = 1;  -- Can't use WHERE on window function directly
```

---

## Pattern 2: CTEs (Complex Queries)

```sql
WITH first_cte AS (
  SELECT col1, col2, COUNT(*) AS cnt
  FROM table1
  GROUP BY col1, col2
),
second_cte AS (
  SELECT f.col1, t2.col3
  FROM first_cte f
  JOIN table2 t2 ON f.col1 = t2.col1
  WHERE f.cnt > 5
)
SELECT * FROM second_cte;
```

**Use when:** Breaking complex logic into readable steps

---

## Pattern 3: Gaps and Islands (Consecutive Sequences)

**Problem:** Find all consecutive periods where condition is true

**Solution (ROW_NUMBER difference method):**
```sql
WITH filtered AS (
  SELECT id, date, value
  FROM table
  WHERE condition = true
),
numbered AS (
  SELECT 
    id, date, value,
    ROW_NUMBER() OVER (ORDER BY id, date) AS global_rn,
    ROW_NUMBER() OVER (PARTITION BY id ORDER BY date) AS group_rn
  FROM filtered
),
islands AS (
  SELECT
    id, date, value,
    global_rn - group_rn AS island_id  -- KEY: This identifies consecutive runs
  FROM numbered
)
SELECT
  id,
  MIN(date) AS start_date,
  MAX(date) AS end_date,
  COUNT(*) AS consecutive_count
FROM islands
GROUP BY id, island_id;
```

**Key insight:** Consecutive rows have the same (global_rn - group_rn) value

---

## Pattern 4: Recursive CTEs (Hierarchies)

**Problem:** Traverse hierarchical data (org charts, categories, chains)

**Template:**
```sql
WITH RECURSIVE hierarchy AS (
  -- ANCHOR: Starting point
  SELECT id, parent_id, name, 1 AS level
  FROM table
  WHERE parent_id IS NULL  -- Root condition
  
  UNION ALL
  
  -- RECURSIVE: Next level
  SELECT t.id, t.parent_id, t.name, h.level + 1
  FROM table t
  INNER JOIN hierarchy h ON t.parent_id = h.id
)
SELECT * FROM hierarchy ORDER BY level;
```

**Must remember:**
- UNION ALL (not UNION)
- Join condition links current level to next level
- Add termination condition if needed: `WHERE level < 10`

---

## Pattern 5: Multi-Table JOINs + Aggregation

```sql
SELECT 
  t1.category,
  COUNT(DISTINCT t2.customer_id) AS unique_customers,
  SUM(t2.amount) AS total_amount,
  AVG(t3.rating) AS avg_rating
FROM table1 t1
LEFT JOIN table2 t2 ON t1.id = t2.foreign_id
LEFT JOIN table3 t3 ON t1.id = t3.foreign_id
WHERE t1.active = 1
GROUP BY t1.category
HAVING COUNT(DISTINCT t2.customer_id) > 100
ORDER BY total_amount DESC;
```

**Remember:**
- JOIN before GROUP BY
- HAVING filters after aggregation, WHERE filters before
- COUNT(DISTINCT col) for unique counts

---

## Common Gotchas

**1. NULL handling:**
```sql
WHERE column IS NULL      -- Not: WHERE column = NULL
WHERE column IS NOT NULL
COALESCE(column, 0)       -- Replace NULL with 0
```

**2. Date functions (SQL Server):**
```sql
DATEADD(day, 1, date_column)
DATEDIFF(day, start_date, end_date)
DATEPART(year, date_column)
```

**3. String functions:**
```sql
CONCAT(col1, ' ', col2)
SUBSTRING(column, start, length)
CHARINDEX('search', column)  -- Returns position (1-based), 0 if not found
```

**4. DISTINCT vs GROUP BY:**
- `SELECT DISTINCT col1, col2` → Unique combinations
- `GROUP BY col1` → Enables aggregations (COUNT, SUM, etc.)

---

## Test-Taking Strategy

**Time allocation:**
- Easy: 15-20 min
- Hard: 45-60 min  
- Extremely hard: Remaining time

**Approach:**
1. Read ALL questions first (5 min)
2. Identify which pattern each question uses
3. Start with easy (build confidence)
4. Plan hard question on paper before coding
5. Submit partial answer on extremely hard if stuck at minute 110

**When stuck:**
- Check if you're filtering before/after the right clause
- Verify JOIN conditions
- Test with simple SELECT * first, then build complexity
- Remember: Partial correctness > zero

**Edge cases to test:**
- Empty result set
- NULL values
- Duplicate rows
- Single row in table
